# Le meilleur solveur retenu est ITS
# Les meilleurs résultats poru chaque instance sont dans le dossier best_results
import solver_iterated_tabu as ITS


def solve(mother):
    return ITS.solve(mother)
